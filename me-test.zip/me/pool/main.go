package main

import (
    "fmt"
    "log"
    "net/http"
    "runtime"
    "sync"
    "time"
	
	_ "net/http/pprof"
//	"github.com/gin-gonic/gin"
)

type WorkerPool struct {
	wg sync.WaitGroup
	jobs chan func()
	numWorkers int
}

func main() {
	
//    http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
//        w.Write([]byte("PProf Profiling is running."))
//    })
//    go func() {
//        log.Println("Starting pprof HTTP server on :6060")
//        if err := http.ListenAndServe(":6060", nil); err != nil {
//            log.Fatal("ListenAndServe: ", err)
//        }
//    }()

	pool := NewWorkerPool(1)
   	
	for i := 0; i < 10; i++ {
		go func() {
        t := time.NewTicker(time.Second)
		for {
            select {
            case time:=<-t.C:
				fmt.Print(time)
				pool.Submit(task)
            }
		}
    	}()
		time.Sleep(time.Millisecond * 100)
	}

	
	pool.wg.Wait()
	
//	r := gin.Default()
//	r.GET("/job", func(c *gin.Context) {
//		pool.Submit(task)
//        c.String(200,"ok")
//    })
//	
//	r.Run(":9000")
}

func NewWorkerPool(numWorkers int) *WorkerPool{
    pool := &WorkerPool{
        jobs:       make(chan func(),5),
        numWorkers: numWorkers,
    }
	pool.wg.Add(numWorkers)
	for i := 0; i < numWorkers; i++ {
		go pool.startWorker(fmt.Sprintf("goroutine-%d",i))
	}
	fmt.Println("num:",runtime.NumGoroutine())
	return pool
}

func (p *WorkerPool) startWorker(name string){
	for {
		select {
	    case  job:=<-p.jobs:
			fmt.Print(name,"->")
			job()
        default:
	    }
	}
}

func (p *WorkerPool) Submit(job func()){
	p.jobs <- job
}

func (p *WorkerPool) stopWorker(){
	
}

func task() {
	fmt.Println(runtime.NumGoroutine())
}