package main

import (
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
)

type HeartRequest struct {
	Server   string `form:"server" binding:"required"`
	SendTime int64  `form:"sendTime" binding:"required"`
}

type Info struct {
	Size int `json:"-"`
	LastSentTime time.Time       `json:"lastSentTime"`
	RTTs         []time.Duration `json:"rtt"`
}

func main() {
	m := make(map[string]*Info)

	r := gin.Default()
	r.GET("/i", func(c *gin.Context) {
		c.JSON(http.StatusOK, m)
	})
	r.POST("/r", func(c *gin.Context) {
		var req HeartRequest
		_ = c.ShouldBind(&req)
		sendTime := time.UnixMicro(req.SendTime)
		RTT := time.Since(sendTime)
		obj, ok := m[req.Server]
		if !ok {
			obj = &Info{
				Size: 0,
				LastSentTime: sendTime,
				RTTs:         make([]time.Duration,0),
			}
		}
		obj.LastSentTime = sendTime
		obj.Size ++
		obj.RTTs = append(obj.RTTs, RTT)
		m[req.Server] = obj

		c.JSON(http.StatusOK, "ok")
	})

	r.Run(":9000")

}