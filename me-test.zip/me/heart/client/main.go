package main

import (
	"bytes"
	"fmt"
	"net/http"
	"time"
)

func main() {
	client := http.Client{}
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			url := fmt.Sprintf("http://127.0.0.1:9000/r?server=%s&sendTime=%d", "client", time.Now().UnixMicro())
			payload := bytes.NewBufferString("")
			req, _ := http.NewRequest("POST", url, payload)
			resp, err := client.Do(req)
			if err != nil {
				continue
			}
			resp.Body.Close()
		}
	}
}
