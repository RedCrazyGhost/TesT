package main

import (
    "context"
    "fmt"
    "net/http"
    "runtime"
    "sync"
    "time"

    _ "net/http/pprof"

)

func main(){
    var wg sync.WaitGroup
    wg.Add(1)
    go func() {
        fmt.Println("Starting pprof server on http://localhost:6060/debug/pprof")
        http.ListenAndServe(":6060", nil)
    }()
    
    wg.Add(1)
    go run(func(ctx context.Context) {
        fmt.Println(runtime.NumGoroutine())
    },context.Background(),&wg)
    wg.Wait()
    
    fmt.Println("running done",runtime.NumGoroutine())
}

func run(do func(ctx context.Context),ctx context.Context, wg *sync.WaitGroup)  {
    defer  wg.Done()
        
    ticker := time.NewTicker(time.Nanosecond)
    defer ticker.Stop()

    for {
        select {
        case <-ctx.Done():
            fmt.Println("timeout done",ctx.Err(),time.Now().String(),runtime.NumGoroutine())
            return 
        case <-ticker.C:
            do(ctx)
        }
    }
    
}

