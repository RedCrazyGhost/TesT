url: https://leetcode.cn/graphql/


requestBody:
```json
{
"operationName": "questionOfToday",
"query": "\n    query questionOfToday {\n  todayRecord {\n    date\n    userStatus\n    question {\n      questionId\n      frontendQuestionId: questionFrontendId\n      difficulty\n      title\n      titleCn: translatedTitle\n      titleSlug\n      paidOnly: isPaidOnly\n      freqBar\n      isFavor\n      acRate\n      status\n      solutionNum\n      hasVideoSolution\n      topicTags {\n        name\n        nameTranslated: translatedName\n        id\n      }\n      extra {\n        topCompanyTags {\n          imgUrl\n          slug\n          numSubscribed\n        }\n      }\n    }\n    lastSubmission {\n      id\n    }\n  }\n}\n    "

}
```


repsonData:
```json
{
    "data": {
        "todayRecord": [
            {
                "date": "2024-07-12",
                "userStatus": null,
                "question": {
                    "questionId": "3226",
                    "frontendQuestionId": "2974",
                    "difficulty": "Easy",
                    "title": "Minimum Number Game",
                    "titleCn": "最小数字游戏",
                    "titleSlug": "minimum-number-game",
                    "paidOnly": false,
                    "freqBar": null,
                    "isFavor": false,
                    "acRate": 0.8993340560631873,
                    "status": null,
                    "solutionNum": 173,
                    "hasVideoSolution": false,
                    "topicTags": [
                        {
                            "name": "Array",
                            "nameTranslated": "数组",
                            "id": "VG9waWNUYWdOb2RlOjU0MA=="
                        },
                        {
                            "name": "Sorting",
                            "nameTranslated": "排序",
                            "id": "VG9waWNUYWdOb2RlOjQyOTU5"
                        },
                        {
                            "name": "Simulation",
                            "nameTranslated": "模拟",
                            "id": "VG9waWNUYWdOb2RlOjU3ODc2"
                        },
                        {
                            "name": "Heap (Priority Queue)",
                            "nameTranslated": "堆（优先队列）",
                            "id": "VG9waWNUYWdOb2RlOjYxMjY0"
                        }
                    ],
                    "extra": {
                        "topCompanyTags": [
                            {
                                "imgUrl": "https://assets.leetcode-cn.com/aliyun-lc-upload/uploaded_files/2022/09/e9108030-576a-4a77-8539-75de09ce5a5a/%E5%85%AC%E5%8F%B8%20Logo%E7%9A%84%E5%89%AF%E6%9C%AC.png",
                                "slug": "amazon",
                                "numSubscribed": 3422
                            },
                            {
                                "imgUrl": "https://pic.leetcode-cn.com/45a64add888e66ff6d3c551bed948528715996937b877aaf6fdc08eae74789f5-google-logo-png-open-2000.png",
                                "slug": "google",
                                "numSubscribed": 5178
                            },
                            {
                                "imgUrl": "https://pic.leetcode-cn.com/c0becdcc322c6ffa7de04f9429fea3cbaa045735fa1771c637d79828358dc8ef-41MVF9VYURL.png",
                                "slug": "yahoo",
                                "numSubscribed": 17
                            }
                        ]
                    }
                },
                "lastSubmission": null
            }
        ]
    }
}
```